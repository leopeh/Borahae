// ===========================
// TEXTO DIGITANDO
// ===========================

const texto =
"Você entrou na minha vida e, desde então, todos os meus dias ficaram melhores. Este pequeno site é só uma forma de mostrar o quanto eu te amo. 💜";

const typing = document.getElementById("typing");

let i = 0;

function escrever() {

    if (i < texto.length) {

        typing.innerHTML += texto.charAt(i);

        i++;

        setTimeout(escrever, 45);

    }

}

escrever();


// ===========================
// ROLAR PARA A SEÇÃO
// ===========================

function ir(id){

    document.getElementById(id).scrollIntoView({

        behavior:"smooth"

    });

}


// ===========================
// CONTADOR
// ALTERE A DATA SE NECESSÁRIO
// ===========================

const inicio = new Date("2026-06-28T00:00:00");

function atualizarTempo(){

    const agora = new Date();

    let diff = agora - inicio;

    const dias = Math.floor(diff / 86400000);

    diff %= 86400000;

    const horas = Math.floor(diff / 3600000);

    diff %= 3600000;

    const minutos = Math.floor(diff / 60000);

    diff %= 60000;

    const segundos = Math.floor(diff / 1000);

    document.getElementById("tempo").innerHTML = `
        <div>${dias} dias</div>
        <div>${horas} horas</div>
        <div>${minutos} minutos</div>
        <div>${segundos} segundos</div>
    `;

}

setInterval(atualizarTempo,1000);

atualizarTempo();


// ===========================
// FRASES
// ===========================

const frases=[

"Você é meu lugar favorito. 💜",

"Meu melhor momento sempre é ao seu lado.",

"Obrigado por existir.",

"Eu escolheria você em qualquer universo.",

"Borahae 💜",

"Você é meu maior presente."

];

const quote=document.querySelector(".quote");

let indice=0;

function trocarFrase(){

    quote.style.opacity=0;

    setTimeout(()=>{

        quote.innerHTML=frases[indice];

        quote.style.opacity=1;

        indice++;

        if(indice>=frases.length){

            indice=0;

        }

    },400);

}

quote.style.transition=".5s";

trocarFrase();

setInterval(trocarFrase,4000);


// ===========================
// SURPRESA
// ===========================

const love=document.getElementById("love");

const surpresa=document.getElementById("surpresa");

love.onclick=()=>{

    surpresa.style.display="flex";

    chuvaCoracoes();

}

surpresa.onclick=()=>{

    surpresa.style.display="none";

}


// ===========================
// CHUVA DE CORAÇÕES
// ===========================

function criarCoracao(){

    const heart=document.createElement("div");

    heart.innerHTML="💜";

    heart.style.position="fixed";

    heart.style.left=Math.random()*100+"vw";

    heart.style.top="-30px";

    heart.style.fontSize=(20+Math.random()*25)+"px";

    heart.style.pointerEvents="none";

    heart.style.transition="6s linear";

    document.body.appendChild(heart);

    setTimeout(()=>{

        heart.style.transform="translateY(110vh) rotate(720deg)";

        heart.style.opacity="0";

    },100);

    setTimeout(()=>{

        heart.remove();

    },6500);

}

function chuvaCoracoes(){

    for(let i=0;i<150;i++){

        setTimeout(criarCoracao,i*60);

    }

}


// ===========================
// GALERIA
// ===========================

document.querySelectorAll(".gallery img").forEach(img=>{

    img.onclick=()=>{

        window.open(img.src);

    }

});


// ===========================
// TÍTULO
// ===========================

let troca=false;

setInterval(()=>{

document.title=troca?

"💜 Borahae 💜":

"❤️ Eu te amo ❤️";

troca=!troca;

},3000);


// ===========================
// BRILHOS NO MOUSE
// ===========================

document.addEventListener("mousemove",(e)=>{

    const estrela=document.createElement("div");

    estrela.innerHTML="✨";

    estrela.style.position="fixed";

    estrela.style.left=e.clientX+"px";

    estrela.style.top=e.clientY+"px";

    estrela.style.pointerEvents="none";

    estrela.style.fontSize="12px";

    estrela.style.opacity="1";

    estrela.style.transition="1s";

    document.body.appendChild(estrela);

    setTimeout(()=>{

        estrela.style.opacity="0";

        estrela.style.transform="translateY(-25px)";

    },10);

    setTimeout(()=>{

        estrela.remove();

    },1000);

});